function displayImage(image, title_string)
figure;
title(title_string);
hold on;
imshow(image);
% colorbar;


% set(gcf, 'title', title_string);
